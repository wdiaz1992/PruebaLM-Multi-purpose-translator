package main

import (
	"fmt"
	"bufio"
	"os"

	controller "multiTranslate/controller"
)

func main(){
	reader := bufio.NewReader(os.Stdin)

	//Obteniendo Texto
	fmt.Println("Ingrese texo a traducir: ")
	textoATraducir,err := reader.ReadString('\n')
	//fmt.Scanln(&textoATraducir)

	if err != nil {
		fmt.Println(err);
	}else {
		//obteniendo formato Origen
		fmt.Println("Seleccione formato origen: ")
		fmt.Println("1->TEXT 2->BINARY 3->MORSE")
		formatoOrigen,errOrigen := reader.ReadString('\n')

		if errOrigen != nil {
			fmt.Println(errOrigen);
		}else{
			//obteniendo formato Destino
			fmt.Println("Seleccione formato destino: ")
			fmt.Println("1->TEXT 2->BINARY 3->MORSE")
			formatoDestino,errDestino := reader.ReadString('\n')

			if errDestino != nil {
				fmt.Println(errDestino);
			}else{
				controller.Translator(textoATraducir,formatoOrigen,formatoDestino);
			}
		}
	}
}