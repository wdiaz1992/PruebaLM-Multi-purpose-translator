package controller

import(
	"fmt"
	"strings"
)

var morsemap = map[string]string{
	"A": ".-",
	"B": "-...",
	"C": "-.-.",
	"D": "-..",
	"E": ".",
	"F": "..-.",
	"G": "--.",
	"H": "....",
	"I": "..",
	"J": ".---",
	"K": "-.-",
	"L": ".-..",
	"M": "--",
	"N": "-.",
	"O": "---",
	"P": ".--.",
	"Q": "--.-",
	"R": ".-.",
	"S": "...",
	"T": "-",
	"U": "..-",
	"V": "...-",
	"W": ".--",
	"X": "-..-",
	"Y": "-.--",
	"Z": "--..",
}

var morsetoTexmap = map[string]string{
	".-":"A",
	"-...":"B",
	"-.-.":"C",
	"-..":"D",
	".":"E",
	"..-.":"F",
	"--.":"G",
	"....":"H",
	"..":"I",
	".---":"J",
	"-.-":"K",
	".-..":"L",
	"--":"M",
	"-.":"N",
	"---":"O",
	".--.":"P",
	"--.-":"Q",
	".-.":"R",
	"...":"S",
	"-":"T",
	"..-":"U",
	"...-":"V",
	".--":"W",
	"-..-":"X",
	"-.--":"Y",
	"--..":"Z",
}

var characterMap = map[string]string{}

func Translator(textoATraducir string,formatoOrigen string,formatoDestino string){

	if(formatoDestino == "1"){
		texto(textoATraducir)
	}


	if(formatoDestino == "2"){
		binary(textoATraducir)
	}

	if(formatoDestino == "3"){
		morse(textoATraducir)
	}
}

func texto(word string){
	fmt.Println("TEXTO")
}

func binary(word string){
	fmt.Println("BINARY")
}

func morse(message string){
	var output string

	message = strings.ToUpper(message)
	words := strings.Split(message, " ")

	//Recorriendo palabras	
	for _, word := range words {
		var delimiter string
		var response string

		if len(word) > 1 {
			delimiter = "   "
		}else{
			delimiter = " "
		}

		//Cambiando caracter por caracter
		for i := 0; i < len(word); i++ {
			response := morsemap[word[i:i+1]]
			
			if response != "" {
				response += response + delimiter
			}
		}
		
		if response != "" {
			output += response
		}
	}

	fmt.Printf("Texto traducido: %s",output)
}